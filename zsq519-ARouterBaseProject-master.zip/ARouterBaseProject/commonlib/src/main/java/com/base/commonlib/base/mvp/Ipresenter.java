package com.base.commonlib.base.mvp;

/**
 * Created by jess on 16/4/28.
 */
public interface Ipresenter {

}

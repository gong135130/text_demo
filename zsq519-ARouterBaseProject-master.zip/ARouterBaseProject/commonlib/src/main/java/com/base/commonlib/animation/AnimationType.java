package com.base.commonlib.animation;

/**
 * @description :
 * @autHor :  V.Wenju.Tian
 * @date : 2016/12/19 12:23
 */

public enum AnimationType {
    ALPHA, SCALE, SLIDE_FROM_BOTTOM, SLIDE_FROM_LEFT, SLIDE_FROM_RIGHT
}

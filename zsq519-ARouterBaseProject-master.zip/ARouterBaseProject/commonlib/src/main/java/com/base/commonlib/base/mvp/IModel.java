package com.base.commonlib.base.mvp;

/**
 * Created by V.Wenju.Tian on 2016/11/29.
 */

public interface IModel {

}
